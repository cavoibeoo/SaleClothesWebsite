create definer = root@localhost trigger TRIGG_UpdateOrderDetails
    before update
    on customer_product
    for each row
BEGIN
	DECLARE myMessage varchar(100);
-- if the update items is change it's status to true
	if new.status = 1 then
    
    -- check if is there inventory left 
		if ((select inventory_left from products where product_id = new.product_id) < new.quantity) then
			SET myMessage = CONCAT("Product ", new.product_id , " is out of stock.");
			SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = myMessage;
		END if;
        
	-- if the customer haven't create order then create order for the first one else just add the product to order details
		if (SELECT COUNT(*) from customer_product WHERE customer_id = new.customer_id and status = 1) = 0 THEN
			insert into orders (customer_id, date) values (new.customer_id, current_timestamp());
		END IF;
        
	-- add product to order details
        SET @new_order_id = (SELECT order_id FROM orders WHERE customer_id=new.customer_id ORDER BY orders.date DESC LIMIT 1);
		INSERT INTO order_products(order_id, product_id, quantity) values (@new_order_id, new.product_id, new.quantity);
        
	-- Decrease the bought quantity
        UPDATE products 
        SET inventory_left = inventory_left - new.quantity
        WHERE product_id = new.product_id;
	END IF;
END;

