create definer = root@localhost trigger TRIGG_UpdateUnitPrice
    before insert
    on order_products
    for each row
BEGIN
	SET new.unit_price = (SELECT unit_price FROM products WHERE product_id = new.product_id);
    SET new.total = new.unit_price * new.quantity;
END;

