create definer = root@localhost trigger TRIGG_UpdateDiscount
    before insert
    on orders
    for each row
BEGIN
	DECLARE currentLevelId int;
    SET currentLevelID = (SELECT level_id from customeraccount where customer_id = new.customer_id);
    SET new.discount = (SELECT discount from levels where level_id = currentLevelId); 
END;

